# LogFileAnalyzer_4740
Programming Assignment #1 for Big Data Technologies 4740

hadoop must be installed and configured and access_log.gz must be in same directory as the Makefile and command.sh script.

1. extract LogFileAnalyzer.zip file
2. enter the unzipped directory
3. copy access_log.gz into the unzipped directory
4. run the desired make target

MAKE TARGETS: 

print the make targets for this project:

$ make

run the MapReduce job:

$ make lastrequest

print the last job's results:

$ make results
